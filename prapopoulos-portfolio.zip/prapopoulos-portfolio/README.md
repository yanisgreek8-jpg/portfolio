# Portfolio — Ivan K.

Static one-page portfolio. Open `index.html` locally, or publish with GitHub Pages
(Settings -> Pages -> Source: Deploy from a branch -> main / root).

## Contents

- `index.html` — the page, all styles inline
- `assets/` — logo and photographs used in the deck

## Case study

**Prapopoulos — drone spraying sales deck.** Self-initiated concept, six slides, English.
Not affiliated with Prapopoulos. Company names, logos and photographs belong to their owners.
Figures on the data slide are published by DJI Agriculture.
